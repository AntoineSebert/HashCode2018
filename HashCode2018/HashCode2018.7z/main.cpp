#include "main.hpp"

using namespace std;

int main(int ac, char** av) {
	Simulation simul = Simulation();
	simul.run();

	system("pause");
	
	return 0;
}